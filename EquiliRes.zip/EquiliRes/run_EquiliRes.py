import argparse
from deeprobust.graph.utils import *
from load_datasets.dataset import Dataset
from load_datasets.attacked_data import PrePtbDataset
from EquiliRes import EquiliRes


parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--dataset', type=str, default='cora_ml', choices=['polblogs','cora_ml','cora', 'citeseer', 'photo'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0.05,  help='pertubation rate')
parser.add_argument('--k', type=int, default=20, help='Truncated Components.')
parser.add_argument('--dataset', type=str, default='meta', choices=['meta','pgd','dice'])
parser.add_argument('--k', type=int, default=20, help='Truncated Components.')
parser.add_argument('--hidden', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')
parser.add_argument('--θ', type=float, default=0.05, choices=[0.05, 0.1 , 0.15, 0.2, 0.25])


args = parser.parse_args()

def main(args):
    args.cuda = torch.cuda.is_available()
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    np.random.seed(args.seed)
    if args.cuda:
        torch.cuda.manual_seed(args.seed)
    data = Dataset(root=f'./dataset/', name=args.dataset, setting='prognn')
    adj, features, labels = data.adj, data.features, data.labels
    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test


    perturbed_data = PrePtbDataset(root=f'./dataset/',
            name=args.dataset,
            attack_method=args.attack,
            ptb_rate=args.ptb_rate)
    perturbed_adj = perturbed_data.adj



    model = EquiliRes(nfeat=features.shape[1], nclass=labels.max()+1,
                    nhid=16,device=device)

    model = model.to(device)


    model.fit(features, perturbed_adj, labels, args.θ, args.dataset, idx_train, idx_val, idx_test, k=args.k, verbose=True)
    model.eval()
    output = model.test(idx_test)

    return output

if __name__ == '__main__':

    main(args)















