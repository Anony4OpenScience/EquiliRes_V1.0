import networkx as nx
import torch
from itertools import combinations

def k_hop_neighbors(graph, node, k):
    neighbors = set()
    current_level_nodes = {node}

    for _ in range(k):
        next_level_nodes = set()
        for n in current_level_nodes:
            next_level_nodes.update(graph.neighbors(n))
        neighbors.update(next_level_nodes)
        current_level_nodes = next_level_nodes

    neighbors.discard(node)
    return neighbors

def jaccard_similarity(set1, set2):
    intersection = len(set1.intersection(set2))
    union = len(set1.union(set2))
    return intersection / union if union > 0 else 0

def k_hop_similarity(graph, node1, node2, k, neighbor_cache):
    if graph.has_edge(node1, node2):
        if (node1, k) not in neighbor_cache:
            neighbor_cache[(node1, k)] = k_hop_neighbors(graph, node1, k)
        if (node2, k) not in neighbor_cache:
            neighbor_cache[(node2, k)] = k_hop_neighbors(graph, node2, k)

        neighbors1 = neighbor_cache[(node1, k)]
        neighbors2 = neighbor_cache[(node2, k)]

        return jaccard_similarity(neighbors1, neighbors2)
    return None

def Caculate(A):
    G = nx.from_numpy_array(A, create_using=nx.DiGraph())
    k = 2
    similarity_matrix = {}
    neighbor_cache = {}

    for node1, node2 in combinations(G.nodes, 2):
        similarity = k_hop_similarity(G, node1, node2, k, neighbor_cache)
        if similarity is not None:
            similarity_matrix[(node1, node2)] = similarity

    return similarity_matrix

def compute_metrics(A):
    A_tensor = torch.tensor(A).cuda()
    in_degree = A_tensor.sum(dim=0)
    out_degree = A_tensor.sum(dim=1)
    degree_centrality = (in_degree + out_degree) / (len(A) - 1)

    if A_tensor.sum() == 0:
        x = 0.0
        y = 0.0
    else:
        x = (torch.sum(A_tensor @ A_tensor) / out_degree.sum()).item()
        y = (torch.sum(out_degree * degree_centrality) / out_degree.sum()).item()

    return x, y

def modify_matrix(A, similarity_matrix):
    min_similarity_edge = min(similarity_matrix.items(), key=lambda item: item[1])
    node1, node2 = min_similarity_edge[0]
    A[node1, node2] = 0
    A[node2, node1] = 0
    del similarity_matrix[min_similarity_edge[0]]
    return A, similarity_matrix

def Alter_Graph(A, θ):
    similarity_matrix = Caculate(A)
    best_A = A.copy()


    x_tmp, y_tmp = 0, 0

    initial_similarity_count = len(similarity_matrix)

    while True:

        min_similarity_edge = min(similarity_matrix.items(), key=lambda item: item[1])

        node1, node2 = min_similarity_edge[0]
        del similarity_matrix[min_similarity_edge[0]]

        tmp_A = best_A.copy()

        if tmp_A[node1, node2] == 1 and tmp_A[node2, node1] == 1:
            tmp_A[node1, node2] = 0
            tmp_A[node2, node1] = 0

        x, y = compute_metrics(tmp_A)

        if x > x_tmp and y > y_tmp:

            x_tmp = x
            y_tmp = y

            best_A = tmp_A
        else:
            tmp_A[node1, node2] = 1
            tmp_A[node2, node1] = 1

        current_similarity_count = len(similarity_matrix)
        if current_similarity_count <= initial_similarity_count * θ:
            break

    return best_A


