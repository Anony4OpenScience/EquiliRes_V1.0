from sklearn.preprocessing import normalize
import networkx as nx
import numpy as np
import scipy
from scipy import sparse

A = scipy.sparse.load_npz('dataset/ori_adj_polblogs.npz')
A3 = A.toarray()
print(A3)
rows, cols = A3.shape
r, c = A3.shape
print(r, c)


G = nx.from_numpy_array(A3, create_using=nx.DiGraph())


G2_weight = normalize(A3, axis=0, norm='l1')

d = nx.degree_centrality(G)
in_sum = 0.0
for v in G.nodes():
    in_sum += d[v]

F = (1 / rows) * in_sum
print(F)

d_w = np.sum(G2_weight, axis=0)
d = np.sum(d_w)
in_n = np.sum(A3, axis=0)
m = np.sum(in_n)

ave_weight = d / m
G = ave_weight
