import numpy as np
import matplotlib
import scipy
from matplotlib.ticker import MultipleLocator
from scipy import sparse
from betaspace import betaspace_F
from β3 import F,G
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import shutil
import os
print("F",F)
print("G",G)

cache_dir = matplotlib.get_cachedir()

# 删除缓存目录
if os.path.exists(cache_dir):
    shutil.rmtree(cache_dir)
    print(f"Deleted Matplotlib cache directory: {cache_dir}")
else:
    print("Matplotlib cache directory does not exist.")



plt.rcParams['axes.unicode_minus'] = False
matplotlib.rcParams['mathtext.default'] = 'regular'

dataset = ''
attack = ''
ptb_rate = ''


A1 = scipy.sparse.load_npz(f'dataset/{dataset}_{attack}_adj_{ptb_rate}%.npz')
A = A1.toarray()


in_degree = np.sum(A, axis=0)
out_degree = np.sum(A, axis=1)


degree_centrality = (in_degree + out_degree) / (len(A) - 1)

β_eff, x_eff = betaspace_F(A, degree_centrality)


c = 31.9
k = 8

xx = np.arange(0.01, 5.01, 0.01)
beta = k * F * (((c * xx) ** 2) + 1) / (G * xx)



plt.plot(beta, xx, color='#000000', linewidth=1, zorder=1)
plt.axvline(x=8.072792, color='red', linestyle='--')
plt.scatter(8.072792, 0.15311126597225666, color='magenta', s=30, marker='^', label='Original', linewidths=1, zorder=2)


# # Metattack
# n_pro=3%
plt.scatter(8.014823, 0.1520118024200201, color='green', s=10, label='3%', zorder=3)
# n_pro=6%
plt.scatter(8.004704, 0.15089921246170998, color='red', s=10, label='6%', zorder=4)
# n_pro=9%
plt.scatter(7.991536, 0.149087442740798, color='black', s=10, label='9%', zorder=5)
# n_pro=12%
plt.scatter(7.850, 0.14825781733989716, color='pink', s=10, label='12%', zorder=6)
# n_pro=15%
plt.scatter(7.805968, 0.1463957892358303, color='blue', s=10, label='15%', zorder=7)
# n_pro=18%
plt.scatter(7.7795477 , 0.1455590619146824, color='purple', s=10, label='18%', zorder=8)
# n_pro=21%
plt.scatter(7.67186, 0.1436392230451107, color='orange', s=10, label='21%', zorder=9)
# n_pro=24%
plt.scatter(7.563217, 0.14265088352560997, color='yellowgreen', s=10, label='24%', zorder=10)
# n_pro=27%
plt.scatter(7.459419, 0.14073767429590225, color='darkgray', s=10, label='27%', zorder=11)
# # n_pro=30%
plt.scatter(7.400067, 0.13703968188166618, color='darkblue', s=10, label='30%', zorder=12)

# # #PGD
# # n_pro=3%
# plt.scatter(7.959108 , 0.1509551052004099, color='green', s=10, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(7.883437, 0.14951989986002445, color='red', s=10, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(7.798578, 0.1479104347527027, color='black', s=10, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(7.732178, 0.14665107242763042, color='pink', s=10, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(7.713309, 0.14629319310188293, color='blue', s=10, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(7.6976967, 0.1459970884025097, color='purple', s=10, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(7.7009106, 0.14605805277824402, color='orange', s=10, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(7.7188153, 0.14639763161540031, color='yellowgreen', s=10, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(7.624057, 0.1446004118770361, color='darkgray', s=10, label='27%', zorder=11)
# # # n_pro=30%
# plt.scatter(7.647651, 0.14504789374768734, color='darkblue', s=10, label='30%', zorder=12)



# # # # DICE
# # n_pro=3%
# plt.scatter(79.71209, 0.15486875902664238, color='green', s=5, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(77.92076, 0.15499093717705636, color='red', s=5, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(76.60619, 0.15499093717705656, color='black', s=5, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(75.47666, 0.15481058388986385, color='pink', s=5, label='12%')
# # n_pro=15%
# plt.scatter(74.03231, 0.15467679316393446, color='blue', s=5, label='15%')
# # n_pro=18%
# plt.scatter(72.30537, 0.15460699599918548, color='purple', s=5, label='18%')
# # n_pro=21%
# plt.scatter(71.298965, 0.15456628310648063, color='orange', s=5, label='21%')
# # n_pro=24%
# plt.scatter(69.62265, 0.15471169346745534, color='yellowgreen', s=5, label='24%')
# # n_pro=27%
# plt.scatter(68.1993, 0.15467097655822545, color='darkgray', s=5, label='27%')
# # # n_pro=30%
# plt.scatter(66.67939, 0.15467679316393448, color='darkblue', s=5, label='30%')


x_major_locator = MultipleLocator(5)
y_major_locator = MultipleLocator(0.1)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim([0, 20])
plt.ylim([-0.01, 1])
plt.yticks(fontsize=1, weight='bold')
plt.xticks(fontsize=1, weight='bold')
plt.tick_params(labelsize=18)

times_new_roman = fm.FontProperties(
    fname='fonts/Times New Roman.ttf',
    size=25)

plt.xlabel(r'$\tilde{\beta}$', fontsize=25, fontproperties=times_new_roman)
plt.ylabel(r'$\tilde{x}$', fontsize=25, fontproperties=times_new_roman)


plt.legend(loc='upper left', fontsize=9)
plt.tight_layout()
plt.show()
