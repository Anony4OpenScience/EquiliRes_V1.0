import numpy as np
import matplotlib
import scipy
from matplotlib.ticker import MultipleLocator
from scipy import sparse
from betaspace import betaspace_F
from β5 import F,G
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import shutil
import os
print("F",F)
print("G",G)

cache_dir = matplotlib.get_cachedir()

# 删除缓存目录
if os.path.exists(cache_dir):
    shutil.rmtree(cache_dir)
    print(f"Deleted Matplotlib cache directory: {cache_dir}")
else:
    print("Matplotlib cache directory does not exist.")



plt.rcParams['axes.unicode_minus'] = False
matplotlib.rcParams['mathtext.default'] = 'regular'

dataset = ''
attack = ''
ptb_rate = ''


A1 = scipy.sparse.load_npz(f'dataset/{dataset}_{attack}_adj_{ptb_rate}%.npz')
A = A1.toarray()


in_degree = np.sum(A, axis=0)
out_degree = np.sum(A, axis=1)


degree_centrality = (in_degree + out_degree) / (len(A) - 1)

β_eff, x_eff = betaspace_F(A, degree_centrality)

c = 24
k = 10
xx = np.arange(0.01, 5.01, 0.01)
beta = k * F * (((c * xx) ** 2) + 1) / (G * xx)

plt.plot(beta, xx, color='#000000', linewidth=2, zorder=1)

plt.axvline(x=18.255857, color='red', linestyle='--')
plt.scatter(18.255857, 0.12998119, color='magenta', s=30, marker='^', label='Original', linewidths=1, zorder=2)


# # Meta
# n_pro=3%
plt.scatter(17.87786, 0.127289845, color='green', s=10, label='3%', zorder=3)
# n_pro=6%
plt.scatter(17.598534, 0.12530107, color='red', s=10, label='6%', zorder=4)
# n_pro=9%
plt.scatter(17.36464, 0.12363574, color='black', s=10, label='9%', zorder=5)
# n_pro=12%
plt.scatter(17.192436, 0.12240966, color='pink', s=10, label='12%', zorder=6)
# n_pro=15%
plt.scatter(17.070713, 0.12154299, color='blue', s=10, label='15%', zorder=7)
# n_pro=18%
plt.scatter(16.979713,  0.12089507, color='purple', s=10, label='18%', zorder=8)
# n_pro=21%
plt.scatter(16.906986, 0.12037726, color='orange', s=10, label='21%', zorder=9)
# n_pro=24%
plt.scatter(16.843191, 0.11992304, color='yellowgreen', s=10, label='24%', zorder=10)
# n_pro=27%
plt.scatter(16.808344, 0.11967494, color='darkgray', s=10, label='27%', zorder=11)
# n_pro=30%
plt.scatter(16.775812, 0.11944331, color='darkblue', s=10, label='30%', zorder=12)

# # # PGD
# #n_pro=3%
# plt.scatter(17.8383, 0.127008194103837, color='green', s=10, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(17.490875, 0.12453453615307808, color='red', s=10, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(17.234602, 0.12270987965166569, color='black', s=10, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(16.817217, 0.11973810382187366, color='pink', s=10, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(16.690863, 0.11883845552802086, color='blue', s=10, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(16.446627, 0.11709950864315033, color='purple', s=10, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(16.39194, 0.11671015061438084, color='orange', s=10, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(16.221428, 0.11549610644578934, color='yellowgreen', s=10, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(16.115187, 0.11473966762423515, color='darkgray', s=10, label='27%', zorder=11)
# # n_pro=30%
# plt.scatter(16.131012, 0.11485234834253788, color='darkblue', s=10, label='30%', zorder=12)

# # #DICE
# # n_pro=3%
# plt.scatter(17.94535, 0.12777037918567657, color='green', s=10, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(17.385487, 0.12570835649967194, color='red', s=10, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(17.218306, 0.12344955466687679, color='black', s=10, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(16.720036, 0.12066802941262722, color='pink', s=10, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(16.491425, 0.11753628961741924, color='blue', s=10, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(16.143038,  0.1172787044197321, color='purple', s=10, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(15.835371, 0.11089875362813473, color='orange', s=10, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(15.316742, 0.11078371666371822, color='yellowgreen', s=10, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(15.364172, 0.10829931125044823, color='darkgray', s=10, label='27%', zorder=11)
# # n_pro=30%
# plt.scatter(15.138134, 0.10589989833533764, color='darkblue', s=10, label='30%', zorder=12)




x_major_locator = MultipleLocator(5)
y_major_locator = MultipleLocator(0.1)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim([0, 30])
plt.ylim([-0.05, 1])
plt.yticks(fontsize=1, weight='bold')
plt.xticks(fontsize=1, weight='bold')
plt.tick_params(labelsize=18)
times_new_roman = fm.FontProperties(fname='fonts/ttf/Times New Roman.ttf', size=25)

plt.xlabel(r'$\tilde{\beta}$', fontsize=25, fontproperties=times_new_roman)
plt.ylabel(r'$\tilde{x}$', fontsize=25, fontproperties=times_new_roman)

plt.legend(loc='upper left', fontsize=9)
plt.axvline(x=18.255857, color='red', linestyle='--')
plt.tight_layout()
plt.show()
