from sklearn.preprocessing import normalize
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import scipy
from scipy import sparse
# A = scipy.sparse.load_npz('../examples/modified/net2.npz')
A = scipy.sparse.load_npz('dataset/ori_adj_cora_ml.npz')
# print(A)
# 将其转化为二维形式的矩阵，也就是邻接矩阵  --矩阵形式
A3 = A.toarray()
print(A3)
# 将其转化成浮点型   将节点之间的边1变为1.0  之后设置权重方便
# 绘制有向图G2
# print(A4)
rows, cols = A3.shape
r, c = A3.shape
print(r, c)
# G = nx.DiGraph()
# for i in range(r):
#     for j in range(c):
#         if A3[i][j] == 1:
#             G.add_edge(i, j)
# for j in range(c):
#     for i in range(r):
#         if A3[j][i] == 1:
#             G.add_edge(j, i)
# G = nx.draw(G)

G = nx.from_numpy_array(A3, create_using=nx.DiGraph())


G2_weight = normalize(A3, axis=0, norm='l1')

d = nx.degree_centrality(G)
in_sum = 0.0
for v in G.nodes():
    # print(v, d[v])
    in_sum += d[v]

F = (1 / rows) * in_sum


d_w = np.sum(G2_weight, axis=0)
d = np.sum(d_w)
# 先求每一列的入度 再求所有列的入度
in_n = np.sum(A3, axis=0)
# print(in_n)
m = np.sum(in_n)

ave_weight = d / m
# 求G函数G(x,x)
G = ave_weight
print(G)
c = 10
k = 0.6
xx = np.arange(0.01, 2.01, 0.01)
# xx = 0.6
beta = k * F * (((c * xx) ** 2) + 1) / (G * xx)
# plt.text(40+1, 0.62, 'A', color='r', fontsize=20)
# plt.text(40+1, 0.025, 'B', color='b', fontsize=20)
# plt.scatter([40], [0.59], c='r', s=25)
# plt.scatter([40], [0.025], c='b', s=25)
# plt.scatter([81.03496],[1.312], c='g',s=10)
# plt.text(11, -0.2, 'β$^c$$_{eff}$', color='#000000', fontsize=18)
# plt.plot([13, 13], [0, 0.9], c='#000000', linestyle='--')
# plt.plot([11, 0], [11, 0.9], c='b', linestyle='--')
# plt.plot([1.5, 1.5], [0, -0.25], c='b', linestyle='--')
# plt.plot(beta, xx, color='#000000')
plt.plot(xx, beta, color='#000000')
plt.axhline(y=-0.01, color='r', linestyle='-')
# plt.xlim([0, 70])
# plt.ylim([-0.05, 1.6])
plt.ylim([0, 120])
plt.xlim([0, 2])
plt.tick_params(labelsize=18)
# plt.xlabel('β$_{eff}$', fontsize=25)
# plt.ylabel('x$_{eff}$', fontsize=25)
plt.xlabel('x$_{eff}$', fontsize=25)
plt.ylabel('β$_{eff}$', fontsize=25)
plt.show()