import numpy as np



def betaspace_F(A, degree_centrality):

    out_degrees = np.sum(A, axis=1)

    if np.sum(np.sum(A, axis=0)) == 0:
        β_eff = 0
        x_eff = 0
    else:
        β_eff = np.sum(np.sum(np.dot(A, A), axis=0))/np.sum(out_degrees)
        x_eff = np.sum(out_degrees * degree_centrality) / np.sum(out_degrees)
    return β_eff, x_eff











