import numpy as np
import matplotlib
import scipy
from matplotlib.ticker import MultipleLocator
from scipy import sparse
from betaspace import betaspace_F
from β4 import F,G
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import shutil
import os
print("F",F)
print("G",G)

cache_dir = matplotlib.get_cachedir()

# 删除缓存目录
if os.path.exists(cache_dir):
    shutil.rmtree(cache_dir)
    print(f"Deleted Matplotlib cache directory: {cache_dir}")
else:
    print("Matplotlib cache directory does not exist.")



plt.rcParams['axes.unicode_minus'] = False
matplotlib.rcParams['mathtext.default'] = 'regular'

dataset = ''
attack = ''
ptb_rate = ''


A1 = scipy.sparse.load_npz(f'dataset/{dataset}_{attack}_adj_{ptb_rate}%.npz')
A = A1.toarray()


in_degree = np.sum(A, axis=0)
out_degree = np.sum(A, axis=1)


degree_centrality = (in_degree + out_degree) / (len(A) - 1)

β_eff, x_eff = betaspace_F(A, degree_centrality)


c = 31.9
k = 8

xx = np.arange(0.01, 5.01, 0.01)
beta = k * F * (((c * xx) ** 2) + 1) / (G * xx)



plt.plot(beta, xx, color='#000000', linewidth=1, zorder=1)
plt.axvline(x=102.95102, color='red', linestyle='--')
plt.scatter(102.95102, 0.5500989407300949, color='magenta', s=30, marker='^', label='Original', linewidths=1, zorder=2)




# Metattack
# n_pro=3%
plt.scatter(101.06935, 0.5400446429848671, color='green', s=10, label='3%', zorder=3)
# n_pro=6%
plt.scatter(99.3452, 0.5308319255709648, color='red', s=10, label='6%', zorder=4)
# n_pro=9%
plt.scatter(98.05311, 0.5239279195666313, color='black', s=10, label='9%', zorder=5)
# n_pro=12%
plt.scatter(95.972984, 0.5128131434321404, color='pink', s=10, label='12%', zorder=6)
# n_pro=15%
plt.scatter(94.35861, 0.5041870847344398, color='blue', s=10, label='15%', zorder=7)
# n_pro=18%
plt.scatter(92.57224, 0.4946419596672058, color='purple', s=10, label='18%', zorder=8)
# n_pro=21%
plt.scatter(90.85106, 0.48544514924287796, color='orange', s=10, label='21%', zorder=9)
# n_pro=24%
plt.scatter(89.700836, 0.4792990908026695, color='yellowgreen', s=10, label='24%', zorder=10)
# n_pro=27%
plt.scatter(87.81627, 0.4692293331027031, color='darkgray', s=10, label='27%', zorder=11)
# # n_pro=30%
plt.scatter(86.42169, 0.4617777094244957, color='darkblue', s=10, label='30%', zorder=12)

# #PGD
# # n_pro=3%
# plt.scatter(100.76996, 0.5384448915719986, color='green', s=10, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(99.19091, 0.5300075560808182, color='red', s=10, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(97.985245, 0.523565299808979, color='black', s=10, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(97.04339, 0.5185326561331749, color='pink', s=10, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(96.27302, 0.5144163593649864, color='blue', s=10, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(95.59204, 0.5107776820659637, color='purple', s=10, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(95.62352, 0.5109459161758423, color='orange', s=10, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(95.02507, 0.5077481642365456, color='yellowgreen', s=10, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(94.92764, 0.5072275549173355, color='darkgray', s=10, label='27%', zorder=11)
# # # n_pro=30%
# plt.scatter(95.13509, 0.5083360522985458, color='darkblue', s=10, label='30%', zorder=12)



# DICE
# # n_pro=3%
# plt.scatter(101.06935, 0.5400446429848671, color='green', s=5, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(99.3452, 0.5308319255709648, color='red', s=5, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(98.05311, 0.5239279195666313, color='black', s=5, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(95.972984, 0.5128131434321404, color='pink', s=5, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(94.35861, 0.5041870847344398, color='blue', s=5, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(92.57224, 0.4946419596672058, color='purple', s=5, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(90.85106, 0.48544514924287796, color='orange', s=5, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(89.700836, 0.4792990908026695, color='yellowgreen', s=5, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(87.81627, 0.4692293331027031, color='darkgray', s=5, label='27%', zorder=11)
# # # n_pro=30%
# plt.scatter(86.42169, 0.4617777094244957, color='darkblue', s=5, label='30%', zorder=12)


x_major_locator = MultipleLocator(15)
y_major_locator = MultipleLocator(0.1)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim([0, 139])
plt.ylim([-0.05, 1])
plt.yticks(fontsize=1, weight='bold')
plt.xticks(fontsize=1, weight='bold')
plt.tick_params(labelsize=18)

times_new_roman = fm.FontProperties(
    fname='fonts/Times New Roman.ttf',
    size=25)

plt.xlabel(r'$\tilde{\beta}$', fontsize=25, fontproperties=times_new_roman)
plt.ylabel(r'$\tilde{x}$', fontsize=25, fontproperties=times_new_roman)


plt.legend(loc='upper left', fontsize=9)
plt.tight_layout()
plt.show()
