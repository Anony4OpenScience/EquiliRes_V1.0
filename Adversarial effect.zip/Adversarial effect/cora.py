import numpy as np
import matplotlib
import scipy
from matplotlib.ticker import MultipleLocator
from scipy import sparse
from betaspace import betaspace_F
from β2 import F,G
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import shutil
import os
print("F",F)
print("G",G)

cache_dir = matplotlib.get_cachedir()

if os.path.exists(cache_dir):
    shutil.rmtree(cache_dir)
    print(f"Deleted Matplotlib cache directory: {cache_dir}")
else:
    print("Matplotlib cache directory does not exist.")



plt.rcParams['axes.unicode_minus'] = False
matplotlib.rcParams['mathtext.default'] = 'regular'

dataset = ''
attack = ''
ptb_rate = ''

A1 = scipy.sparse.load_npz(f'dataset/{dataset}_{attack}_adj_{ptb_rate}%.npz')
A = A1.toarray()


in_degree = np.sum(A, axis=0)
out_degree = np.sum(A, axis=1)


degree_centrality = (in_degree + out_degree) / (len(A) - 1)

β_eff, x_eff = betaspace_F(A, degree_centrality)



c = 21
k = 10

xx = np.arange(0.01, 5.01, 0.01)
beta = k * F * (((c * xx) ** 2) + 1) / (G * xx)

plt.plot(beta, xx, color='#000000', linewidth=1, zorder=1)
plt.axvline(x=11.24127, color='red', linestyle='--')
plt.scatter(11.24127, 0.18101884052157402, color='magenta', s=30, marker='^', label='Original', linewidths=1, zorder=2)




# # Metattack
# n_pro=3%
plt.scatter(11.070119, 0.17938997596502304, color='green', s=10, label='3%', zorder=3)
# n_pro=6%
plt.scatter(11.008169, 0.17639239910244942, color='red', s=10, label='6%', zorder=4)
# n_pro=9%
plt.scatter(10.956425, 0.1732033033668995, color='black', s=10, label='9%', zorder=5)
# n_pro=12%
plt.scatter(10.892179, 0.17002283339202404, color='pink', s=10, label='12%', zorder=6)
# n_pro=15%
plt.scatter(10.739005, 0.1675588552057743, color='blue', s=10, label='15%', zorder=7)
# n_pro=18%
plt.scatter(10.613149, 0.16640496855974197, color='purple', s=10, label='18%', zorder=8)
# n_pro=21%
plt.scatter(10.423165, 0.1684644252061844, color='orange', s=10, label='21%', zorder=9)
# n_pro=24%
plt.scatter(10.25235, 0.16315538084506989, color='yellowgreen', s=10, label='24%', zorder=10)
# n_pro=27%
plt.scatter(10.186253, 0.16292194736003876, color='darkgray', s=10, label='27%', zorder=11)
# # n_pro=30%
plt.scatter(10.111322, 0.1617410607933998, color='darkblue', s=10, label='30%', zorder=12)

# # #PGD
# # n_pro=3%
# plt.scatter(10.936838, 0.17611654475331306, color='green', s=10, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(10.771034, 0.17344659194350243, color='red', s=10, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(10.593924, 0.17059458419680595, color='black', s=10, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(10.635968, 0.17127163708209991, color='pink', s=10, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(10.502763, 0.16912659630179405, color='blue', s=10, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(10.325553, 0.16627298668026924, color='purple', s=10, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(10.271367, 0.165400430560112, color='orange', s=10, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(10.165763, 0.1636998914182186, color='yellowgreen', s=10, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(10.11026, 0.16280610114336014, color='darkgray', s=10, label='27%', zorder=11)
# # # n_pro=30%
# plt.scatter(10.062988, 0.16204489395022392, color='darkblue', s=10, label='30%', zorder=12)



# # # # # DICE
# # n_pro=3%
# plt.scatter(10.897775, 0.17548749223351479, color='green', s=5, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(10.942122, 0.17620164901018143, color='red', s=5, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(10.667257, 0.1717754639685154, color='black', s=5, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(10.622002, 0.17104672268033028, color='pink', s=5, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(10.24632, 0.16499709337949753, color='blue', s=5, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(10.075612, 0.162248183041811, color='purple', s=5, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(10.101981, 0.16267279163002968, color='orange', s=5, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(9.821169, 0.15815086662769318, color='yellowgreen', s=5, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(9.717763, 0.15648571774363518, color='darkgray', s=5, label='27%', zorder=11)
# # # n_pro=30%
# plt.scatter(9.701974, 0.15623144805431366, color='darkblue', s=5, label='30%', zorder=12)


x_major_locator = MultipleLocator(5)
y_major_locator = MultipleLocator(0.1)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim([0, 20])
plt.ylim([-0.01, 1])
plt.yticks(fontsize=1, weight='bold')
plt.xticks(fontsize=1, weight='bold')
plt.tick_params(labelsize=18)

times_new_roman = fm.FontProperties(
    fname='fonts/Times New Roman.ttf',
    size=25)

plt.xlabel(r'$\tilde{\beta}$', fontsize=25, fontproperties=times_new_roman)
plt.ylabel(r'$\tilde{x}$', fontsize=25, fontproperties=times_new_roman)


plt.legend(loc='upper left', fontsize=9)
plt.tight_layout()
plt.show()