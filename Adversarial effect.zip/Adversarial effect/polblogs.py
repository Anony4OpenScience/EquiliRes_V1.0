import numpy as np
import matplotlib
import scipy
from matplotlib.ticker import MultipleLocator
from scipy import sparse
from betaspace import betaspace_F
from β1 import F,G
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import shutil
import os
print("F",F)
print("G",G)

cache_dir = matplotlib.get_cachedir()

# 删除缓存目录
if os.path.exists(cache_dir):
    shutil.rmtree(cache_dir)
    print(f"Deleted Matplotlib cache directory: {cache_dir}")
else:
    print("Matplotlib cache directory does not exist.")



plt.rcParams['axes.unicode_minus'] = False
matplotlib.rcParams['mathtext.default'] = 'regular'

dataset = ''
attack = ''
ptb_rate = ''


A1 = scipy.sparse.load_npz(f'dataset/{dataset}_{attack}_adj_{ptb_rate}%.npz')
A = A1.toarray()


in_degree = np.sum(A, axis=0)
out_degree = np.sum(A, axis=1)


degree_centrality = (in_degree + out_degree) / (len(A) - 1)

β_eff, x_eff = betaspace_F(A, degree_centrality)

c = 16.6
k = 0.45

xx = np.arange(0.01, 5.01, 0.01)
beta = k * F * (((c * xx) ** 2) + 1) / (G * xx)
plt.plot(beta, xx, color='#000000', linewidth=2)


plt.plot(beta, xx, color='#000000', linewidth=1, zorder=1)
plt.axvline(x=81.26355, color='red', linestyle='--')
plt.scatter(81.24555, 0.5324392914772034, color='magenta', s=30, marker='^', label='Original', linewidths=1, zorder=2)


# # Metattack
# n_pro=3%
plt.scatter(79.237236, 0.5191628336906433, color='green', s=10, label='3%', zorder=3)
# n_pro=6%
plt.scatter(77.683304, 0.508981466293335, color='red', s=10, label='6%', zorder=4)
# n_pro=9%
plt.scatter(76.515945, 0.5013329982757568, color='black', s=10, label='9%', zorder=5)
# n_pro=12%
plt.scatter(75.62041, 0.49546533823013306, color='pink', s=10, label='12%', zorder=6)
# n_pro=15%
plt.scatter(74.72542, 0.4896014332771301, color='blue', s=10, label='15%', zorder=7)
# n_pro=18%
plt.scatter(74.050804, 0.4851813316345215, color='purple', s=10, label='18%', zorder=8)
# n_pro=21%
plt.scatter(73.26586, 0.4800384044647217, color='orange', s=10, label='21%', zorder=9)
# n_pro=24%
plt.scatter(72.783264, 0.476876437664032, color='yellowgreen', s=10, label='24%', zorder=10)
# n_pro=27%
plt.scatter(72.31514, 0.47380921244621277, color='darkgray', s=10, label='27%', zorder=11)
# # n_pro=30%
plt.scatter(72.313225, 0.4737967252731323, color='darkblue', s=10, label='30%', zorder=12)

# # #PGD
# # n_pro=3%
# plt.scatter(79.497574, 0.5208685994148254, color='green', s=10, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(77.99059, 0.5109948515892029, color='red', s=10, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(76.82111, 0.5033324360847473, color='black', s=10, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(75.95365, 0.49764880537986755, color='pink', s=10, label='12%', zorder=6)
# # n_pro=15%
# plt.scatter(75.24949, 0.4930351674556732, color='blue', s=10, label='15%', zorder=7)
# # n_pro=18%
# plt.scatter(74.883385, 0.4906364679336548, color='purple', s=10, label='18%', zorder=8)
# # n_pro=21%
# plt.scatter(73.9883, 0.4847717881202698, color='orange', s=10, label='21%', zorder=9)
# # n_pro=24%
# plt.scatter(73.94059, 0.4844592213630676, color='yellowgreen', s=10, label='24%', zorder=10)
# # n_pro=27%
# plt.scatter(73.592674, 0.4821797013282776, color='darkgray', s=10, label='27%', zorder=11)
# # # n_pro=30%
# plt.scatter(73.36434, 0.48068368434906006, color='darkblue', s=10, label='30%', zorder=12)



# # # # DICE
# # n_pro=3%
# plt.scatter(79.71209, 0.15486875902664238, color='green', s=5, label='3%', zorder=3)
# # n_pro=6%
# plt.scatter(77.92076, 0.15499093717705636, color='red', s=5, label='6%', zorder=4)
# # n_pro=9%
# plt.scatter(76.60619, 0.15499093717705656, color='black', s=5, label='9%', zorder=5)
# # n_pro=12%
# plt.scatter(75.47666, 0.15481058388986385, color='pink', s=5, label='12%')
# # n_pro=15%
# plt.scatter(74.03231, 0.15467679316393446, color='blue', s=5, label='15%')
# # n_pro=18%
# plt.scatter(72.30537, 0.15460699599918548, color='purple', s=5, label='18%')
# # n_pro=21%
# plt.scatter(71.298965, 0.15456628310648063, color='orange', s=5, label='21%')
# # n_pro=24%
# plt.scatter(69.62265, 0.15471169346745534, color='yellowgreen', s=5, label='24%')
# # n_pro=27%
# plt.scatter(68.1993, 0.15467097655822545, color='darkgray', s=5, label='27%')
# # # n_pro=30%
# plt.scatter(66.67939, 0.15467679316393448, color='darkblue', s=5, label='30%')


x_major_locator = MultipleLocator(20)
y_major_locator = MultipleLocator(0.1)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim([0, 90])
plt.ylim([-0.01, 1])
plt.yticks(fontsize=1, weight='bold')
plt.xticks(fontsize=1, weight='bold')
plt.tick_params(labelsize=18)

times_new_roman = fm.FontProperties(
    fname='fonts/Times New Roman.ttf',
    size=25)

plt.xlabel(r'$\tilde{\beta}$', fontsize=25, fontproperties=times_new_roman)
plt.ylabel(r'$\tilde{x}$', fontsize=25, fontproperties=times_new_roman)

plt.legend(loc='upper left', fontsize=9)
plt.tight_layout()
plt.show()
